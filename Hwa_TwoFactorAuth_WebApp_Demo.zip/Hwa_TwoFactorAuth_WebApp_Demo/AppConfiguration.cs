﻿namespace TwoFactorAuthWebApp
{
    public class AppConfiguration
    {
        public string? WebAPIUrl { get; set; }
    }
}
