﻿using System;

namespace TwoFactorAuthWebApp.Models
{
    public class MemberViewModel
    {
        public DateTime date { get; set; }
        public string? temperatureC { get; set; }
        public string? temperatureF { get; set; }
        public string? summary { get; set; }

    }
}
